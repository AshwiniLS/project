<?php

namespace Drupal\data_module\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Data entities.
 *
 * @ingroup data_module
 */
class DataDeleteForm extends ContentEntityDeleteForm {


}
