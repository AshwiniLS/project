<?php

namespace Drupal\data_module\Entity;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityChangedInterface;
use Drupal\user\EntityOwnerInterface;

/**
 * Provides an interface for defining Data entities.
 *
 * @ingroup data_module
 */
interface DataInterface extends ContentEntityInterface, EntityChangedInterface, EntityOwnerInterface {

  // Add get/set methods for your configuration properties here.

  /**
   * Gets the Data name.
   *
   * @return string
   *   Name of the Data.
   */
  public function getName();

  /**
   * Sets the Data name.
   *
   * @param string $name
   *   The Data name.
   *
   * @return \Drupal\data_module\Entity\DataInterface
   *   The called Data entity.
   */
  public function setName($name);

  /**
   * Gets the Data creation timestamp.
   *
   * @return int
   *   Creation timestamp of the Data.
   */
  public function getCreatedTime();

  /**
   * Sets the Data creation timestamp.
   *
   * @param int $timestamp
   *   The Data creation timestamp.
   *
   * @return \Drupal\data_module\Entity\DataInterface
   *   The called Data entity.
   */
  public function setCreatedTime($timestamp);

  /**
   * Returns the Data published status indicator.
   *
   * Unpublished Data are only visible to restricted users.
   *
   * @return bool
   *   TRUE if the Data is published.
   */
  public function isPublished();

  /**
   * Sets the published status of a Data.
   *
   * @param bool $published
   *   TRUE to set this Data to published, FALSE to set it to unpublished.
   *
   * @return \Drupal\data_module\Entity\DataInterface
   *   The called Data entity.
   */
  public function setPublished($published);

}
