<?php

/**
 * @file
 * Contains \Drupal\data_module\Controller\DataController.
 */
namespace Drupal\data_module\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;

class DataController extends ControllerBase {
	
	
	// /**
	// * Drupal\Core\Form\AccountProxy definition.
	// *
	// * @var \Drupal\Core\Form\AccountProxy
	// */
	// protected $currentUser;

	// /**
	// * {@inheritdoc}
	// */
	// public function __construct(AccountProxyInterface $current_user) {
		// $this->currentUser = $current_user;
	// }
	// /**
	// * {@inheritdoc}
	// */
	// public static function create(ContainerInterface $container) {
		// return new static(
			// $container->get('current_user')
		// );
	// }
		
	public function export() {
	  
		return array(
			'#type' => 'markup',
			'#markup' => $this->t('export')
		);
	}
	
	public function import() {
		
		// global $base_url;
		// $user = \Drupal::currentUser();
		// $path = '/mypayroll/'. $user->id();

		// $response = new \Symfony\Component\HttpFoundation\RedirectResponse($base_url . $path);
		// return $response->send();
		
		return array(
			'#type' => 'markup',
			'#markup' => $this->t('import')
		);
		
		
		
	}
	
	public function update() {
	  
		return array(
			'#type' => 'markup',
			'#markup' => $this->t('updatecsv')
		);
	}
	
}