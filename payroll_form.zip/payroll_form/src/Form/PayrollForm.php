<?php
/**
 * @file
 * Contains \Drupal\payroll_form\Form\PayrollForm.
 */
namespace Drupal\payroll_form\Form;
use \Drupal\user\Entity\User;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Render\MainContent\AjaxRenderer;
use Drupal\Core\Ajax\ReplaceCommand;
use Drupal\Core\Ajax\CommandInterface;
use Drupal\Core\Form\FormAjaxResponseBuilder;

class PayrollForm extends FormBase {
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'payroll_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $form['UID'] = array(
		'#title' => t('User ID:'),
		'#type' => 'entity_autocomplete',
		'#target_type' => 'user',
		'#default_value' => $entity,
		'#required' => TRUE,
		'#executes_submit_callback' => FALSE,
		'#selection_settings' => [
			'include_anonymous' => FALSE,
		], 
		'#ajax' => array(
			'callback' => '::payroll_ajax_form',
			'wrapper' => 'copied-text-field',
			'effect' => 'fade',
			'event' => 'autocompleteclose',
			'progress' => array(
				'type' => 'throbber',
				'message' => NULL,
			),
		),
    );
	
    $form['First_Name'] = array(
		'#title' => t('First Name:'),	
		'#type' => 'textfield',
		'#prefix' => '<div id="copied-First_Name">',
		'#suffix' => '</div>',
		
    );

	 $form['Last_Name']= array(
		'#title' => t('Last Name:'),
		'#type' => 'textfield',
		'#prefix' => '<div id="copied-Last_Name">',
		'#suffix' => '</div>',
    );
	
    $form['Basic_Salary'] = array (
		'#type' => 'number',
		'#title' => t('Basic Salary'),
		'#ajax' => array(
			'callback' => '::payroll_one_ajax_form',
			'wrapper' => 'my-text-field',
			'effect' => 'fade',
			'event' => 'mouseout',
			'progress' => array(
				'type' => 'throbber',
				'message' => NULL,
			),
		),
    );
	
	$form['HRA'] = array (
		'#type' => 'number',
		'#title' => t('HRA'),
		'#prefix' => '<div id="my-HRA">',
		'#suffix' => '</div>',
    );
	
	$form['Medical_Alloance'] = array (
      '#type' => 'number',
      '#title' => t('Medical Alloance'),
	  '#prefix' => '<div id="my-Medical_Alloance">',
	  '#suffix' => '</div>',
    );
	
	$form['Net_Salary'] = array (
      '#type' => 'number',
      '#title' => t('Net Salary'),
	  '#prefix' => '<div id="my-Net_Salary">',
	  '#suffix' => '</div>',
    );
	
    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Submit'),
      '#button_type' => 'primary',
    );
    return $form;
  }
  
/**
 * Implments hook_form()
 */
function payroll_ajax_form(&$form, FormStateInterface $form_state, $form_id) {

	$response = new AjaxResponse();
	
	$id=$form_state->getValue('UID');
	$account = \Drupal\user\Entity\User::load($id); 
    $name = $account->getUsername();
	if (isset($account->field_first_name)) {
		$firstname = $account->field_first_name->value;
	}
	if (isset($account->field_last_name)) {
		$lastname = $account->field_last_name->value;
	}
	$form['First_Name']['#value'] = $firstname;
    $form['Last_Name']['#value'] =  $lastname;
	
	$response->addCommand(new HtmlCommand('#copied-First_Name',drupal_render($form['First_Name'])));
	$response->addCommand(new HtmlCommand('#copied-Last_Name',drupal_render($form['Last_Name'])));
	return $response;
	
}


/**
 * Implments hook_form()
 */
function payroll_one_ajax_form(&$form, FormStateInterface $form_state, $form_id) {

	$response = new AjaxResponse();
	
	$basic=$form_state->getValue('Basic_Salary');
	$hra=0.14*$basic;
	$ma=0.10*$basic;
	$total=$basic+$hra+$ma;
	
	
	$form['HRA']['#value'] = $hra;
    $form['Medical_Alloance']['#value'] = $ma;
	$form['Net_Salary']['#value'] =  $total;
	
	$response->addCommand(new HtmlCommand('#my-HRA',drupal_render($form['HRA'])));
	$response->addCommand(new HtmlCommand('#my-Medical_Alloance',drupal_render($form['Medical_Alloance'])));
	$response->addCommand(new HtmlCommand('#my-Net_Salary',drupal_render($form['Net_Salary'])));
	
	return $response;
	
}



  /**
   * {@inheritdoc}
   */
    public function validateForm(array &$form, FormStateInterface $form_state) {

    }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

  

    foreach ($form_state->getValues() as $key => $value) {
      drupal_set_message($key . ': ' . $value);
    }

   }
}