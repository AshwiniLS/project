<?php
/**
 * @file
 * Contains \Drupal\payroll_form\Form\PayrollForm.
 */
namespace Drupal\payroll_form\Form;
use \Drupal\user\Entity\User;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Render\MainContent\AjaxRenderer;

class PayrollForm extends FormBase {
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'payroll_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $form['UID'] = array(
		'#title' => t('User ID:'),
		'#type' => 'entity_autocomplete',
		'#target_type' => 'user',
		'#default_value' => $entity,
		'#required' => TRUE,
		'#executes_submit_callback' => FALSE,
		'#selection_settings' => [
			'include_anonymous' => FALSE,
		], 
		'#ajax' => array(
			'callback' => '::payroll_form_form_alter',
			'event' => 'autocompleteclose',
			'progress' => false,
		),
    );
	
    $form['First_Name'] = array(
		'#title' => t('First Name:'),	
		'#type' => 'textfield',
		'#value' => $firstname,
		
		
    );

	 $form['Last_Name']= array(
		'#type' => 'textfield',
		'#value' => $firstname,
		'#title' => t('Last Name:'),
    );
	
    $form['Basic_Salary'] = array (
		'#type' => 'number',
		'#title' => t('Basic Salary'),
    );
	
	$form['HRA'] = array (
		'#type' => 'number',
		'#title' => t('HRA'),
    );
	
	$form['Medical_Alloance'] = array (
      '#type' => 'number',
      '#title' => t('Medical Alloance'),
    );
	
	$form['Net_Salary'] = array (
      '#type' => 'number',
      '#title' => t('Net Salary'),
    );
	
    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Save'),
      '#button_type' => 'primary',
    );
    return $form;
  }
  
  /**
 * Implements hook_form_FORM_alter().
 */
function payroll_form_form_alter(&$form, FormStateInterface $form_state, $form_id) {
	
	if($form_id = "payroll_form")
	{
	$id=$form_state->getValue('UID');
	$account = \Drupal\user\Entity\User::load($id); 
    $name = $account->getUsername();
	if (isset($account->field_first_name)) {
		$firstname = $account->field_first_name->value;
	}
	if (isset($account->field_last_name)) {
		$lastname = $account->field_last_name->value;
	}
	
	$form['field_First_Name']['#value'] = $firstname;
	$form['field_Last_Name']['#value'] = $lastname;
	
	var_dump($lastname);
	die();
	}
	return $form;
}
/*
public function ajaxValidateLocalitybyPostalCode(array &$form, FormStateInterface $form_state) {
  $ajax_response = new AjaxResponse();
  $ajax_response->addCommand(new HtmlCommand('.locality-wrapper', $form['locality']));
  return $ajax_response;
} 
 */

  /**
   * {@inheritdoc}
   */
    public function validateForm(array &$form, FormStateInterface $form_state) {

     $firstname= $form_state->getValue('User_Name')->firstname; 
	 $form['Last_Name']= $form_state->getValue('User_Name')->lastname;
      
 
    }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

   // drupal_set_message($this->t('@can_name ,Your application is being submitted!', array('@can_name' => $form_state->getValue('candidate_name'))));

    foreach ($form_state->getValues() as $key => $value) {
      drupal_set_message($key . ': ' . $value);
    }

   }
}